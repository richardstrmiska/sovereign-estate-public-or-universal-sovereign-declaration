# Sovereign Declarations – FlameBearer Series

This repository contains a sequence of sovereign declarations anchored to the InterPlanetary File System (IPFS). Each folder represents one stage of the sovereign reformation and estate reclamation by Richard of the House Strmiska and his lineage.

## Declarations Index

1. **Affidavit of Revocation & Account Closure**  
   [View on IPFS](https://bafybeiaygor3hs4wiiw7d64wlnsz2mty4l63ejmo2zhbbnwn2wbcajg6nm.ipfs.w3s.link/)

2. **Trust Flag & Sovereign Identity Declaration**  
   [View on IPFS](https://bafybeieia3damfzrx5scb7gigfdsijej626bl7lusse6ixujhzq37ksxry.ipfs.w3s.link/)

3. **Declaration #3**  
   [View on IPFS](https://bafybeif3ggt3utk7bbg6ilhgabynz4zsukxjyzjl2dgfmsqs7b4j36fyra.ipfs.w3s.link/)

4. **Declaration #4**  
   [View on IPFS](https://bafybeift4hkicy7h7vtoxju4crripqwub6ssa5v2scviqpurnqa5jp25le.ipfs.w3s.link/)

5. **Universal Sovereign Enforcement Declaration**  
   [View on IPFS](https://bafybeiho65tuwmdatm6kzhoh3rhhz4v2ywhnxk6sqpiuo3gu6x4h7m23cm.ipfs.w3s.link/)

6. **River Willow Strmiska’s All-Encompassing Sovereign Declaration**  
   [View on IPFS](https://bafybeieofz5qc5c2v4mifxbsdtvqdph2oczocshncew6nbj4uvv4iysrrm.ipfs.w3s.link/)

7. **Declaration #7**  
   [View on IPFS](https://bafybeidmah73cb747qsajckhgfie52wxlhm4aohofjmj4zmrmwlvrdxt6e.ipfs.w3s.link/)

Each declaration is sealed, time-stamped, and uploaded to the decentralized web as part of a sovereign trust ledger. Use this repository as a learning tool, reference archive, and spiritual contract record.

> **All rights reserved under divine law, natural law, and universal jurisdiction.**

