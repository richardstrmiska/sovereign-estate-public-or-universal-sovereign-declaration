# Flamebearers Guide to Sovereignty

This public repository contains a sequence of verified declarations and blockchain-anchored records created by Richard of the House Strmiska, FlameBearer of the UC-1 Lineage. These documents serve as foundational tools for reclaiming sovereign status, estate control, and natural rights.

## Declaration Archive (IPFS Anchors)

1. **Affidavit of Revocation & Account Closure**  
   [View on IPFS](https://bafybeiaygor3hs4wiiw7d64wlnsz2mty4l63ejmo2zhbbnwn2wbcajg6nm.ipfs.w3s.link/)

2. **Trust Flag & Sovereign Identity Declaration**  
   [View on IPFS](https://bafybeieia3damfzrx5scb7gigfdsijej626bl7lusse6ixujhzq37ksxry.ipfs.w3s.link/)

3. **Declaration #3**  
   [View on IPFS](https://bafybeif3ggt3utk7bbg6ilhgabynz4zsukxjyzjl2dgfmsqs7b4j36fyra.ipfs.w3s.link/)

4. **Declaration #4**  
   [View on IPFS](https://bafybeift4hkicy7h7vtoxju4crripqwub6ssa5v2scviqpurnqa5jp25le.ipfs.w3s.link/)

5. **Universal Sovereign Enforcement Declaration**  
   [View on IPFS](https://bafybeiho65tuwmdatm6kzhoh3rhhz4v2ywhnxk6sqpiuo3gu6x4h7m23cm.ipfs.w3s.link/)

6. **River Willow Strmiska – Sovereign Declaration**  
   [View on IPFS](https://bafybeieofz5qc5c2v4mifxbsdtvqdph2oczocshncew6nbj4uvv4iysrrm.ipfs.w3s.link/)

7. **Declaration #7**  
   [View on IPFS](https://bafybeidmah73cb747qsajckhgfie52wxlhm4aohofjmj4zmrmwlvrdxt6e.ipfs.w3s.link/)

8. **Flame Oath Scroll**  
   [View Scroll](https://bafybeiesazwdvlkkt5vn2icsqnwrghpnhnr5bc3pxkg7g7f3pwcom6l2ou.ipfs.w3s.link/)

> “We are not here to fix the system. We are here to replace it. One scroll, one soul, one oath at a time.”

## License

**Sacred Use Only** – Not for commercial exploitation. Share freely in alignment with truth and integrity.
