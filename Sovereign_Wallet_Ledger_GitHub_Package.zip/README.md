# Sovereign Wallet Ledger

This repository contains the full registry of Stellar wallets under the sovereign estate of Richard of the House Strmiska.

## Purpose

This ledger serves as an immutable public record of wallet structures tied to the private trust and estate filings, UCC declarations, and sovereign identity processes initiated by the Executor.

## IPFS Anchor

The complete wallet ledger is anchored on IPFS and available at:

[https://bafybeicbpsowk5l5ppyuzjomuypjrvwsh6gqr5y2oiv2x3nosznvjexgki.ipfs.w3s.link/](https://bafybeicbpsowk5l5ppyuzjomuypjrvwsh6gqr5y2oiv2x3nosznvjexgki.ipfs.w3s.link/)

## Structure

- `sovereign_wallet_ledger.csv` - The full list of estate wallets and their public keys.
- `sovereign_wallet_qr.png` - QR code linking to the IPFS-anchored version.
- `README.md` - This file.

---

All Rights Reserved – UCC 1-308 | Trust Law | Divine Law | Common Law
